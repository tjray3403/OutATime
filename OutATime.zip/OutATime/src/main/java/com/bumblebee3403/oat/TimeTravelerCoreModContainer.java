package com.bumblebee3403.oat;

import java.util.Arrays;

import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;

import net.minecraftforge.fml.common.DummyModContainer;
import net.minecraftforge.fml.common.LoadController;
import net.minecraftforge.fml.common.ModMetadata;
import net.minecraftforge.fml.common.event.FMLConstructionEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;



public class TimeTravelerCoreModContainer extends DummyModContainer
{
    public TimeTravelerCoreModContainer()
    {
        super(new ModMetadata());
        ModMetadata meta = getMetadata();
        meta.modId = "oat";
        meta.name = "Out A Time";
        meta.version = "0.1";
        meta.credits = "Was By Charsmud";
        meta.authorList = Arrays.asList("Bumblebee3403,Charsmud");
        meta.description = "Core ASM hooks for TimeTraveler :)";
        meta.url = "http://www.minecraftforum.net/topic/1211757-timetraveler-real-time-travel-inside-of-minecraft-go-to-your-past/";
        meta.updateUrl = "";
        meta.screenshots = new String[0];
        meta.logoFile = "";
    }

    @Override
    public boolean registerBus(EventBus bus, LoadController controller)
    {
        bus.register(this);
        return true;
    }

    @Subscribe
    public void modConstruction(FMLConstructionEvent evt)
    {
    }

    @Subscribe
    public void init(FMLInitializationEvent evt)
    {
    }

    @Subscribe
    public void preInit(FMLPreInitializationEvent evt)
    {
    }

    @Subscribe
    public void postInit(FMLPostInitializationEvent evt)
    {
    }
}
