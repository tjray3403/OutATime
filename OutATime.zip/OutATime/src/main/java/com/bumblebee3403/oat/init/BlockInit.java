package com.bumblebee3403.oat.init;

import java.util.ArrayList;
import java.util.List;

import com.bumblebee3403.oat.blocks.BlockBase;
import com.bumblebee3403.oat.blocks.BlockTimeMachine;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;

public class BlockInit {
	
	public static final List<Block> BLOCKS = new ArrayList<Block>();
	
	//public static final Block Block_time_machine = new BlockTimeMachine("block_time_machine", Material.IRON);
	//public static final Block Block_collision = new BlockTimeMachine("block_collision", Material.IRON);


}
