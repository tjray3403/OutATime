package com.bumblebee3403.oat.futuretravel;

import com.bumblebee3403.oat.init.DimensionInit;

import net.minecraft.init.Biomes;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeProvider;
import net.minecraft.world.biome.BiomeProviderSingle;
import net.minecraft.world.gen.IChunkGenerator;

public class WorldProviderFuture extends WorldProvider
{

	private WorldType terrainType;

	
	public WorldProviderFuture() {
		//this.biomeProvider = terrainType.getBiomeProvider(world);
	//	this.biomeProvider = new BiomeProvider());
				}
				
				
	/**@Override
	public void registerWorldChunkManager()
	{    
		this.worldChunkMgr = new WorldChunkManagerHell(BiomeGenBase.desertHills, 0.1F);  
	}
	*/
	@Override
    public IChunkGenerator createChunkGenerator()     
	{               
		return new ChunkProviderFuture(world, world.getSeed(), true, null);      
	}
		
	public int getMoonPhase(long worldTime)
    {
        return (int)(worldTime / 24000L % 8L + 8L) % 8;
    }
	
	@Override
	public DimensionType getDimensionType() {
		// TODO Auto-generated method stub
		return DimensionInit.Future;
	}
	
	@Override
	public boolean isSurfaceWorld()
    {
        return true;
    }
	
	
	@Override
	public boolean canRespawnHere()
    {
        return true;
    }

	
	@Override
	public boolean canCoordinateBeSpawn(int par1, int par2) {
		return true;
	}
	
	
	
}
