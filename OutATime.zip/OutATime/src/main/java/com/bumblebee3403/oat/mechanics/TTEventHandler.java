package com.bumblebee3403.oat.mechanics;

import java.io.IOException;
import java.util.List;

import com.bumblebee3403.oat.Main;
import com.bumblebee3403.oat.entity.EntityXPOrbTT;
import com.bumblebee3403.oat.entity.ExtendedEntity;
import com.bumblebee3403.oat.gui.GuiTimeTravel;
import com.bumblebee3403.oat.items.ItemExpEnhance;
import com.bumblebee3403.oat.pasttravel.PastAction;
import com.bumblebee3403.oat.pasttravel.PastActionTypes;
import com.bumblebee3403.oat.pasttravel.PastMechanics;

import net.minecraft.block.Block;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketCombatEvent.Event;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.EntityEvent.EntityConstructing;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.player.ArrowLooseEvent;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.event.world.BlockEvent.BreakEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;


public class TTEventHandler
{
	@SubscribeEvent
	public void onBucketFill(FillBucketEvent event) 
	{

		ItemStack result = fillCustomBucket(event.getWorld(), event.getTarget());

		if (result == null)
			return;

		//event.setResult(result);
		event.setResult(event.getResult().ALLOW);
		//event.getEntityPlayer().inventory.mainInventory[event.entityPlayer.inventory.currentItem] = event.getResult();
		event.getEntityPlayer().setHeldItem(EnumHand.MAIN_HAND, event.getFilledBucket());
		System.out.println(event.getResult());
	}

	public ItemStack fillCustomBucket(World world, RayTraceResult pos) 
	{
		//Block blockID = world.getBlock(pos.blockX, pos.blockY, pos.blockZ);
		//System.out.println(blockID + " " + Main.timeLiquid);
		//if (blockID == Main.timeLiquid) {
			//System.out.println("IT WORKED");
		//	world.setBlock(pos.blockX, pos.blockY, pos.blockZ, Blocks.air);
		//	return new ItemStack(Main.bucket);
	//	} else
			return null;
	}

	@SubscribeEvent
	public void onBlockBreakEvent(BreakEvent event)
	{
		if(!GuiTimeTravel.isInPast)
		{
			List<PastAction> aList = Main.instance.getActionListForPlayer(event.getPlayer());

			if (aList != null)
			{
				PastAction ma = new PastAction(PastActionTypes.BREAKBLOCK);
				ma.xCoord = event.getPos().getX();
				ma.yCoord = event.getPos().getY();
				ma.zCoord = event.getPos().getZ();
				aList.add(ma);
				System.out.println("BREAKING BLOCK");
			}
		}
		else
		{
			if(ParadoxBlockLevels.paradoxAmountsForBlocks().getParadoxBlockLevelList().containsKey(event.getState()))
			{
				System.out.println(event.getState());
				int paradox = Main.vars.getParadoxAmt() + (Integer)(ParadoxBlockLevels.paradoxAmountsForBlocks().getParadoxBlockLevelList().get(event.getState()));
				System.out.println(paradox);
				Main.vars.setParadoxAmt(paradox);
			}
		}
		
	}
	@SubscribeEvent
	public void onLivingPlaceBlockEvent(LivingPlaceBlockEvent event) {
		Side side = FMLCommonHandler.instance().getEffectiveSide();

		if(!GuiTimeTravel.isInPast)
		{
			if (side == Side.SERVER) {
				if (event.getEntityLiving() instanceof EntityPlayerMP) {
					EntityPlayerMP thePlayer = (EntityPlayerMP) event.getEntityLiving();
					List<PastAction> aList = Main.instance
							.getActionListForPlayer(thePlayer);

					if (aList != null) {
						PastAction ma = new PastAction(
								PastActionTypes.PLACEBLOCK);
						event.theItem.writeToNBT(ma.itemData);
						ma.xCoord = event.xCoord;
						ma.yCoord = event.yCoord;
						ma.zCoord = event.zCoord;
						aList.add(ma);
					}
				}
			}
		}
	}
	@SubscribeEvent
	public void onArrowLooseEvent(ArrowLooseEvent ev) throws IOException
	{
		Side side = FMLCommonHandler.instance().getEffectiveSide();
		if (side == Side.SERVER)
		{
			List<PastAction> aList = Main.instance.getActionListForPlayer(ev.getEntityPlayer());
			if (aList != null)
			{
				PastAction pa = new PastAction(PastActionTypes.SHOOTARROW);
				pa.arrowCharge = ev.getCharge();
				aList.add(pa);
			}
		}
	}

	@SubscribeEvent
	public void onItemTossEvent(ItemTossEvent ev) throws IOException 
	{
		System.out.println("EVENTS WORKING");
	
		List<PastAction> aList = Main.instance.getActionListForPlayer(ev.getPlayer());
		if (aList != null) 
		{
			PastAction ma = new PastAction(PastActionTypes.DROP);

			ev.getEntityItem().writeToNBT(ma.itemData);

			aList.add(ma);
		}
	}

	@SubscribeEvent
	public void onServerChatEvent(ServerChatEvent ev) 
	{
		Side side = FMLCommonHandler.instance().getEffectiveSide();
		if (side == Side.SERVER)
		{
			List<PastAction> aList = Main.instance
					.getActionListForPlayer(ev.getPlayer());
			if (aList != null)
			{
				PastAction ma = new PastAction((byte) 1);
				ma.message = ev.getMessage();
				aList.add(ma);
			}
		}
	}

	boolean inPast;

	@SubscribeEvent
	public void onEntityJoin(EntityJoinWorldEvent event)
	{/**
		if(event.getEntity() instanceof EntityXPOrb)
		{
			EntityXPOrb xp = (EntityXPOrb)event.getEntity();
			InventoryPlayer inventory = FMLClientHandler.instance().getClient().player.inventory;
			int enhancers = 0;
			for(int i = 0; i < inventory.getSizeInventory(); i++)
			{
				if(inventory.getStackInSlot(i) != null)
				{
					if(inventory.getStackInSlot(i).getItem() instanceof ItemExpEnhance)
					{
						int size = inventory.getStackInSlot(i).getCount();
						enhancers = enhancers + size;
					}
				}
			}
			if(enhancers > 0)
			{
				event.getEntity().setDead();
				int xpVal = xp.getXpValue() * enhancers;
				System.out.println(xpVal);
				EntityXPOrbTT orb = new EntityXPOrbTT(event.getWorld(), event.getEntity().posX, event.getEntity().posY, event.getEntity().posZ, xpVal);
				orb.world.spawnEntity(orb);
			}
		}
		
		inPast = GuiTimeTravel.isInPast;
		PastMechanics mechanics = new PastMechanics();
		if (event.getEntity() instanceof EntityLiving) 
		{
			//ExtendedEntity props = ExtendedEntity.get((EntityLiving) event.getEntity());
			if (inPast) 
			{
			//	if (Main.vars.pathData.data.containsKey(props.getEntityUID()))
				{
					// System.out.println("NOT A PAST ENTITY");
					// event.entity.setDead();
				}
			}
		}*/
	}

	@SubscribeEvent
	public void onEntityConstructing(EntityConstructing event)
	{
		/*
		 * Be sure to check if the entity being constructed is the correct type
		 * for the extended properties about to add! The null check may not be
		 * necessary - I only use it to make sure properties are only registered
		 * once per entity.
		 */
		//if (event.getEntity() instanceof EntityLiving && ExtendedEntity.get((EntityLiving) event.getEntity()) == null) 
		{
			//ExtendedEntity.register((EntityLiving) event.getEntity());
		}
		// That will call the constructor as well as cause the init() method to
		// be called automatically
		//if (event.getEntity() instanceof EntityLiving && event.getEntity().getExtendedProperties(ExtendedEntity.EXT_PROP_NAME) == null)
		{
			//event.getEntity()registerExtendedProperties(ExtendedEntity.EXT_PROP_NAME, new ExtendedEntity((EntityLiving) event.getEntity()));
		}
	}
}
