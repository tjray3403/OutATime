package com.bumblebee3403.oat.pasttravel;

import net.minecraft.block.Block;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.nbt.NBTTagCompound;

public class PastAction 
{
	public byte type;
	public String message;
	public int armorId;
	public EntityEquipmentSlot armorSlot;
	public int armorDmg;
	public NBTTagCompound itemData;
	public int arrowCharge;
	public int xCoord;
	public int yCoord;
	public int zCoord;
	public Block blockType;
	public int blockMeta;
	public PastAction(byte chat)
	{
		super();
		this.type = chat;
		this.itemData = new NBTTagCompound();
		
	}
}
