package com.bumblebee3403.oat;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;

import com.bumblebee3403.oat.futuretravel.FutureTravelMechanics;
import com.bumblebee3403.oat.mechanics.TTEventHandler;
import com.bumblebee3403.oat.pasttravel.PastAction;
import com.bumblebee3403.oat.pasttravel.TimeTravelerPastRecorder;
import com.bumblebee3403.oat.proxy.CommonProxy;
import com.bumblebee3403.oat.util.Reference;
import com.bumblebee3403.oat.util.handlers.RegistryHandler;

import net.minecraft.command.CommandException;
import net.minecraft.command.EntitySelector;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = Reference.MOD_ID, name = Reference.NAME, version = Reference.VERSION)
public class Main {
	
	public static UnchangingVars vars = new UnchangingVars();
	public static SimpleNetworkWrapper snw;

	
	@Instance
	public static Main instance;
	
	@SidedProxy(clientSide = Reference.CLIENT_PROXY_CLASS, serverSide = Reference.COMMON_PROXY_CLASS)
	public static CommonProxy proxy;
	public static int dimensionId = 100;
	public static int pastdimensionId = 101;

	private static FutureTravelMechanics ftm;
	public static Logger logger = LogManager.getLogger(Reference.MOD_ID);
	
	

	
	@EventHandler
	public static void PreInit(FMLPreInitializationEvent event) {
		snw = NetworkRegistry.INSTANCE.newSimpleChannel(Reference.MOD_ID);
		snw.registerMessage(TimeTravelerPacketHandler.class, Message.class, 0, Side.CLIENT);
		
		FMLCommonHandler.instance().bus().register(new TTEventHandler());
		FMLCommonHandler.instance().bus().register(new Ticker());
		MinecraftForge.EVENT_BUS.register(new TTEventHandler());
		MinecraftForge.EVENT_BUS.register(new Ticker());
		
		
		RegistryHandler.preInitRegistries();
	}
	
	@EventHandler
	public static void init(FMLInitializationEvent event) {
		
		mkDirs();
	
		RegistryHandler.initRegistries();
		
		
		ftm = new FutureTravelMechanics();	

		
	}
	
	@EventHandler
	public static void Postinit(FMLPostInitializationEvent event) {
		
	}
	

	

	
	@SuppressWarnings("rawtypes")
	public Map<EntityPlayer, TimeTravelerPastRecorder> recordThreads = Collections.synchronizedMap(new HashMap());
	 
	public static EntityPlayerMP getPlayerForName(ICommandSender sender, String name) throws CommandException
	{
		EntityPlayerMP var2 = EntitySelector.matchOnePlayer(sender, name);
		if (var2 != null)
		{
			return var2;
		}
		return getPlayerForName(name);
	}

	public static EntityPlayerMP getPlayerForName(String name)
	{
		EntityPlayerMP tempPlayer = (FMLCommonHandler.instance().getMinecraftServerInstance()).getPlayerList().getPlayerByUsername(name);
		if (tempPlayer != null) 
		{
			return tempPlayer;
		}
		List<EntityPlayerMP> possibles = new LinkedList();
		ArrayList<EntityPlayerMP> temp = (ArrayList) FMLCommonHandler.instance().getSidedDelegate().getServer().getPlayerList().getPlayers();
		for (EntityPlayerMP player : temp)
		{
			if (player.getDisplayName().toString().equalsIgnoreCase(name))
			{
				return player;
			}
			if (player.getDisplayName().toString().toLowerCase().contains(name.toLowerCase())) 
			{
				possibles.add(player);
			}
		}
		if (possibles.size() == 1)
		{
			return (EntityPlayerMP) possibles.get(0);
		}
		return null;
	}
	
	public List<PastAction> getActionListForPlayer(EntityPlayer ep)
	{
		TimeTravelerPastRecorder aRecorder = (TimeTravelerPastRecorder) this.recordThreads.get(ep);
		if (aRecorder == null) 
		{
			return null;
		}
		return aRecorder.eventsList;
	}
	
	public static void mkDirs()
	{
		File pastCreation = new File(FMLClientHandler.instance().getClient().mcDataDir + "/mods/TimeMod/past");
		File presentCreation = new File(FMLClientHandler.instance().getClient().mcDataDir + "/mods/TimeMod/present");
		File futureCreation = new File(FMLClientHandler.instance().getClient().mcDataDir +"/mods/TimeMod/future");

		
		pastCreation.mkdirs();
		presentCreation.mkdirs();
		futureCreation.mkdirs();

	}
	
	/**
	 * Initiates mod, registers block and item for use.  Generates the necessary folders.
	 */

	
}
