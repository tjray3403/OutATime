package com.bumblebee3403.oat.gui;

import com.bumblebee3403.oat.entity.EntityTimecart;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class SlotTimecartFuel extends Slot {

	private EntityTimecart entityTimecart;
	private int removeCount;
	private EntityPlayer entity;

	public SlotTimecartFuel(IInventory inventoryIn, int index, int xPosition, int yPosition, EntityTimecart ett, EntityPlayer entityPlayer) {
		super(inventoryIn, index, xPosition, yPosition);
		entityTimecart = ett;
		entity = entityPlayer;
	}
	
	@Override
	public boolean isItemValid(ItemStack stack) {
		return (new ItemStack(Blocks.TNT, (int) (1)).getItem() == stack.getItem());
	}
	
	@Override
	public ItemStack onTake(EntityPlayer player, ItemStack stack) {
		this.onCrafting(stack);
		super.onTake(player, stack);
		return stack;
		
	}
	
	@Override
	public ItemStack decrStackSize(int amount) {
		
		if(this.getHasStack()) this.removeCount += Math.min(amount, this.getStack().getCount());
		return super.decrStackSize(amount);
		
	}


	@Override
	public void onSlotChanged() {
		super.onSlotChanged();
		slotChanged(0, 0, 0);
	}

	private void slotChanged(int i, int j, int k) {
		entityTimecart.setCurrentEnergy(entityTimecart.getCurrentEnergy() + 50);
		//flux.
		
	}
	
}
