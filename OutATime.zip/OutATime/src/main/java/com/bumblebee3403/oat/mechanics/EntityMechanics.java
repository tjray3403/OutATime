package com.bumblebee3403.oat.mechanics;

import java.util.List;

import net.minecraft.entity.EntityLiving;
import net.minecraft.world.World;
 /**
  * Entity Mechanics
  * @author Charsmud
  *
  */
public class EntityMechanics
{
	public void spawnEntity(EntityLiving entity, World world, int x, int y, int z)
	{
		entity.posX = x;
		entity.posY = y;
		entity.posZ = z;
		world.spawnEntity(entity);
	}
	
	public void despawnAllEntities(World world)
	{
		List entitiesInWorld = world.loadedEntityList;
		
		for(int i = 0; i < entitiesInWorld.size(); i++)
		{
			if(entitiesInWorld.get(i) instanceof EntityLiving)
			{
				((EntityLiving)entitiesInWorld.get(i)).setDead();
			}
		}
	}
}
