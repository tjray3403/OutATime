package com.bumblebee3403.oat.util.handlers;

import java.lang.reflect.Field;

import com.bumblebee3403.oat.Main;
import com.bumblebee3403.oat.blocks.tileentity.TileEntityCollision;
import com.bumblebee3403.oat.blocks.tileentity.TileEntityTimeMachine;
import com.bumblebee3403.oat.gui.GuiHandler;
import com.bumblebee3403.oat.gui.GuiTimeTravel;
import com.bumblebee3403.oat.init.BlockInit;
import com.bumblebee3403.oat.init.DimensionInit;
import com.bumblebee3403.oat.init.EntityInit;
import com.bumblebee3403.oat.init.ItemInit;
import com.bumblebee3403.oat.util.IHasModel;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

@EventBusSubscriber
public class RegistryHandler {
	
	@SubscribeEvent
	public static void onItemRegister(RegistryEvent.Register<Item> event)
	{
		event.getRegistry().registerAll(ItemInit.ITEMS.toArray(new Item[0]));
	}
	
	@SubscribeEvent
	public static void onBlockRegister(RegistryEvent.Register<Block> event)
	{
		event.getRegistry().registerAll(BlockInit.BLOCKS.toArray(new Block[0]));
	}


	
	
	@SubscribeEvent
	public static void onModelRegister(ModelRegistryEvent event) {
		
		for(Item item : ItemInit.ITEMS) {
			if(item instanceof IHasModel) {
				((IHasModel)item).registerModels();
			}
		}
		for(Block block : BlockInit.BLOCKS) {
			if(block instanceof IHasModel) {
				((IHasModel)block).registerModels();
			}
		}
		
	}
	
	
	
	public static void preInitRegistries() {
		
		EntityInit.registerEntities();
		RenderHandler.registerEntityRenderers();
		
		DimensionInit.registerDimension();
	}
	
	@SubscribeEvent
    public static void registerSoundEvents(RegistryEvent.Register<SoundEvent> event) {
        try {
            for (Field f : SoundHandler.class.getDeclaredFields()) {
                Object obj = f.get(null);
                if (obj instanceof SoundEvent) {
                    event.getRegistry().register((SoundEvent) obj);
                }
            }
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

	public static void initRegistries() {
		// TODO Auto-generated method stub
		NetworkRegistry.INSTANCE.registerGuiHandler(Main.instance, new GuiHandler());

		//TileEntity.register("collide", TileEntityCollision.class);
		//TileEntity.register("timemachine", TileEntityTimeMachine.class);
		//GameRegistry.registerTileEntity(TileEntityCollision.class, "collide");
		GameRegistry.registerTileEntity(TileEntityTimeMachine.class, "timemachine");
		
		
		
		
	}
	
	
}
