package com.bumblebee3403.oat.blocks.tileentity;

import net.minecraft.tileentity.TileEntity;

public class TileEntityTimeMachine extends TileEntity {
	
	public TileEntityTimeMachine() {
		
	}

}
