package com.bumblebee3403.oat.futuretravel;

import java.lang.reflect.Field;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.WeakHashMap;

import com.bumblebee3403.oat.mechanics.ClientMethods;
import com.google.common.collect.Iterables;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.Tuple;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.village.Village;
import net.minecraft.village.VillageCollection;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.NibbleArray;
import net.minecraft.world.chunk.storage.ExtendedBlockStorage;
import net.minecraft.world.gen.feature.WorldGenBigTree;
import net.minecraft.world.gen.feature.WorldGenTaiga1;
import net.minecraft.world.gen.feature.WorldGenTaiga2;
import net.minecraft.world.gen.feature.WorldGenTrees;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.util.ChunkCoordComparator;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

/**
 * Contains information about the future mechanics
 * @author Charsmud
 *
 */
public class FutureTravelMechanics
{
	
	/**
	 * Constructor
	 */
	public FutureTravelMechanics()
	{
	}
	Random random = new Random();
	/**
	 * Main expanding forests method
	 * @param world
	 * @param size
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 */
	public void expandForests(World world, int size)
	{
		if(ClientMethods.isSinglePlayer())
		{
			try
			{
    			HashSet<ChunkPos> hashChunk = ReflectionHelper.getPrivateValue(World.class, world, "activeChunkSet", "field_72993_I");
				
    			Iterator itr = hashChunk.iterator();

		         //Iterator<ChunkCoordIntPair> iterator = world.activeChunkSet.iterator();
		         ArrayList<ChunkPos> list = new ArrayList<ChunkPos>();
		         ArrayList<Integer> treeTypes = new ArrayList<Integer>();
		         while(itr.hasNext())
		         {
		        	 ChunkPos coords = (ChunkPos)itr.next();
		                 Chunk currentScanningChunk = world.getChunkFromChunkCoords(coords.x, coords.z);
		                 int h = currentScanningChunk.getTopFilledSegment();
		                 for (int i = 0; i < 8; ++i) {
		                         int x = random.nextInt(16);
		                         int z = random.nextInt(16);
		                         int y = currentScanningChunk.getHeightValue(x, z) - 1;
		                         BlockPos bpn = new BlockPos(x,y,z);
		                         if (y >= 0 && currentScanningChunk.getBlockState(bpn) == Blocks.LEAVES) {
		                         double dx = random.nextDouble();
		                         double dz = random.nextDouble();
		                         double o_ = (double)(dx * dx + dz * dz);
		                         o_ = 8.0D / MathHelper.sqrt(o_) + 8.0 * random.nextDouble() * random.nextDouble();
		                         int x_ = (int)(dx * o_) + (x += currentScanningChunk.x << 4);
		                         int z_ = (int)(dz * o_) + (z += currentScanningChunk.z << 4);
		                         int y_ = world.getHeight(x_, z_) - 1;
		                         BlockPos bpe = new BlockPos(x_, y_, z_);
		                         BlockPos bpee = new BlockPos(x_, y_ + 1, z_);

		                         if (y_ == -1 || world.getBlockState(bpe) != Blocks.GRASS || world.getBlockState(bpee) != Blocks.AIR || (y - y_) > 32 || (y - y_) < 3)
		                         continue;
		                         list.add(new ChunkPos(x_, z_));
		                         BlockPos pos = new BlockPos(x,y,z);
								treeTypes.add(world.getChunkFromBlockCoords(pos).hashCode());//getBlockMetadata(x, y, z));
		                         }
		                 }
		         }
		        // System.out.println(">> " + list.size());
		         Iterator<Integer> typeIterator = treeTypes.iterator();
		         ExtendedBlockStorage cc = null;
		         for (ChunkPos coord : list)
		         {
		        	 if (typeIterator.hasNext())
		             {
		        		 growTree(typeIterator.next() & 3, world, world.getHeight(coord.x, coord.z), coord.hashCode(), coord.z, random);
		             }
		         }
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
	}
	/**
	 * Grows the trees
	 * @param meta
	 * @param par1World
	 * @param par2
	 * @param par3
	 * @param par4
	 * @param par5Random
	 */
	public void growTree(int meta, World par1World, int par2, int par3, int par4, Random par5Random)
	{
	         int l = meta & 3;
	         Object object = null;
	         int i1 = 0;
	         int j1 = 0;

	         if (l == 1)
	         {
	                 object = new WorldGenTaiga2(true);
	         }
	         else if (l == 2)
	         {
	                 object = new WorldGenTaiga1();
	         }
	         else if (l == 3)
	         {
	         if (par5Random.nextInt(10) == 0)
	                 {
	         object = new WorldGenBigTree(true);
	                 }

	                 if (object == null)
	                 {
	                         j1 = 0;
	                         i1 = 0;
	                         object = new WorldGenTrees(true);
	                 }
	         }
	         else
	         {
	                 object = new WorldGenTrees(true);

	                 if (par5Random.nextInt(10) == 0)
	                 {
	                         object = new WorldGenBigTree(true);
	                 }
	         }
	         BlockPos eee = new BlockPos( par2 + i1, par3, par4 + j1);
	         ((WorldGenerator)object).generate(par1World, par5Random, eee);
	}
	/**
	 * Ore Mappings and Max Ore Range
	 */
    public static final Map<Block, Tuple> oreExpansion = new HashMap();
    { // value range for maximum ore in a chunk
            oreExpansion.put(Blocks.REDSTONE_ORE, new Tuple(150, 200)); //24.8  25,50
            oreExpansion.put(Blocks.IRON_ORE, new Tuple(150, 300)); //77  77,154
            oreExpansion.put(Blocks.COAL_ORE, new Tuple(140, 200)); // 142.6  143, 284
            oreExpansion.put(Blocks.GOLD_ORE, new Tuple(70, 140)); //8.2  8, 16
            oreExpansion.put(Blocks.LAPIS_ORE, new Tuple(50, 100)); //3.43  3, 7
            oreExpansion.put(Blocks.DIAMOND_ORE, new Tuple(50, 100)); //3.097  3, 6
    }

    /**
     * Contains Chunk Stuff
     */
    public static WeakHashMap<Chunk, Long> basis = new WeakHashMap();
    Map<ChunkPos, Integer> placements = new LinkedHashMap<ChunkPos, Integer>();
    Set<Entry<ChunkPos, Integer>> p2 = new HashSet<Entry<ChunkPos, Integer>>();
    /**
     * Expands ores
     * @param world
     */
    public void expandOres(World world)
    {
    	if(ClientMethods.isSinglePlayer())
    	{
    		try
    		{
    			
    			HashSet<ChunkPos> hashChunk = ReflectionHelper.getPrivateValue(World.class, world, "activeChunkSet", "field_72993_I");
    			Iterator<ChunkPos> iterator = hashChunk.iterator();
                //Iterator<ChunkCoordIntPair> iterator = world.activeChunkSet.iterator();
                
                Map<ChunkPos, Integer> placements = new HashMap();
                
                Set<Integer> oreIDs = new HashSet();
                for (Block block : oreExpansion.keySet())
                        oreIDs.add(Block.getIdFromBlock(block));
                
                while(iterator.hasNext())
                {
                	System.out.println("ITERATOR");
                	ChunkPos coords = iterator.next();
                        Chunk currentScanningChunk = world.getChunkFromChunkCoords(coords.x, coords.z);
                        long base;
                        if (!basis.containsKey(currentScanningChunk))
                                basis.put(currentScanningChunk, base = currentScanningChunk.getRandomWithSeed(253L).nextLong());
                        else
                                base = basis.get(currentScanningChunk);
                        Map<Integer, List<ChunkPos>> possible = new HashMap();
                        for (int i : oreIDs)
                                possible.put(i, new ArrayList());
                      /**  ExtendedBlockStorage[] blockStorage = currentScanningChunk.getBlockStorageArray();
                        for (int i = 0; i < blockStorage.length && blockStorage[i] != null; ++i)
                        {
                        	System.out.println("BLOCKSLSB");
                                ExtendedBlockStorage storage = blockStorage[i];
                                
								byte[] blockIds;
								byte[] blocksLSB = storage.getData().getDataForNBT(blockIds, data);
                                for (int j = 0; j < blocksLSB.length; ++j)
                                {
                                        if (blocksLSB[j] != 0 && oreIDs.contains(blocksLSB[j]&255))
                                        {
                                        	System.out.println("POSSIBLE");
                                                possible.get(blocksLSB[j]&255).add(new ChunkPos((j & 15) + (coords.x << 4), (j >> 4 & 15) + (coords.z << 4)));
                                        }
                                }
                        }*/
                        for (Map.Entry<Block, Tuple> oreProbability : oreExpansion.entrySet())
                        {
                        	System.out.println("OREPROBABLILITY");
                                int blockID = Block.getIdFromBlock(oreProbability.getKey());
                                List<ChunkPos> genCoords = possible.get(blockID);
                                if (genCoords.size() == 0)
                                        continue;
                                Tuple t = oreProbability.getValue();
                                int min = (Integer)t.getFirst();
                                int max = (Integer)t.getSecond();
                                int chunkCount = (int)((base ^ blockID * 6364136223846793005L + 1442695040888963407L) % (max - min + 1) + min);
                                int attempts = chunkCount - genCoords.size();
                                if (attempts > 0)
                                {
                                	System.out.println("ATTEMPTS");
                                        attempts = random.nextInt(attempts + 1);
                                        attempts = random.nextInt(attempts + 1);
                                        for (int i = 0; i < attempts && genCoords.size() > 0; i ++)
                                        {
                                                placements.put(genCoords.remove(random.nextInt(genCoords.size())), blockID);
                                        }
                                }
                        }
                }
                for (Iterator<Map.Entry<ChunkPos, Integer>> iter = placements.entrySet().iterator(); iter.hasNext();)
                {
                	System.out.println("MAP.ENTRY");
                        Map.Entry<ChunkPos, Integer> entry = iter.next();
                        ChunkPos location = entry.getKey();
                        int x = location.x, y = world.getHeight(location.x, location.z), z = location.z;
                        switch (random.nextInt(6))
                        {
                                case 0:
                                        --y;
                                        break;
                                case 1:
                                        ++y;
                                        break;
                                case 2:
                                        --z;
                                        break;
                                case 3:
                                        ++z;
                                        break;
                                case 4:
                                        --x;
                                        break;
                                case 5:
                                        ++x;
                        }
                        BlockPos wew = new BlockPos(x, y, z);
                    if (world.getBlockState(wew) == Blocks.STONE)
                    {
                        System.out.println("SETBLOCK");
                        world.setBlockState(wew, (IBlockState) Block.getBlockById(entry.getValue()));
                    }
                }
    		}
    		catch(Exception ex)
    		{
    			ex.printStackTrace();
    		}
    	}
    }


    
    public void expandVillages(World world)
    {
    	VillageCollection worldVillages = world.villageCollection;
    	List<Village> villageList = worldVillages.getVillageList();
    
        Iterator iterator = villageList.iterator();
        //StructureVillagePieces villagePieces = new StructureVillagePieces();
        while(iterator.hasNext())
        {
        	Village village = (Village)iterator.next();
        	//village.
        	//ArrayList listOfPieces = villagePieces.getStructureVillageWeightedPieceList(new Random(), 9);
               
        }
    }
    public static void launchWorld(String folderName, String worldName, WorldSettings ws)
    {
    	if(FMLClientHandler.instance().getClient().isSingleplayer())
    	{
    		FMLClientHandler.instance().getClient().launchIntegratedServer(folderName, worldName, ws);
    	}
    }
    

    final class OreEntry<K, V> implements Map.Entry<K, V> 
    {
        private final K key;
        private V value;

        public OreEntry(K key, V value)
        {
            this.key = key;
            this.value = value;
        }

        @Override
        public K getKey()
        {
            return key;
        }

        @Override
        public V getValue() 
        {
            return value;
        }

        @Override
        public V setValue(V value)
{
            V old = this.value;
            this.value = value;
            return old;
        }
    }

}
	



