package com.bumblebee3403.oat.gui;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import com.bumblebee3403.oat.Main;
import com.bumblebee3403.oat.dimension.TeleporterTime;
import com.bumblebee3403.oat.dimension.TravelUtil;
import com.bumblebee3403.oat.init.DimensionInit;
import com.bumblebee3403.oat.mechanics.CopyFile;
import com.bumblebee3403.oat.mechanics.EntityMechanics;
import com.bumblebee3403.oat.pasttravel.PastMechanics;
import com.bumblebee3403.oat.util.Reference;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Teleporter;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.FMLClientHandler;
/**
 * GUI for the Paradox Cube
 * @author Charsmud
 *
 */
public class OldGui extends GuiContainer {

public static boolean isInPast = false;
private ArrayList timeList;
//
/** the currently selected world */
private int selectedWorld;

private String localizedWorldText;

private boolean selected = false;

//private GuiTimeSlot timeSlotContainer;

File source;
public static File staticsource;

private GuiButton buttonSelect;
 static final Minecraft mc = Minecraft.getMinecraft();
  static final MinecraftServer ms = mc.getIntegratedServer();
  WorldInfo wi = mc.world.getWorldInfo();
  public  File directory;
  public File[] files;
  public int timezone;
  public int num;
  
  public File worldInPast;
  public boolean travel;
  
  public OldGui() {
	   super(new GuiTimeContainer());
	   
	  }

  public OldGui(World world, int x, int y, int z, EntityPlayer entity) {
   super(new GuiTimeContainer());
   
   this.xSize = 200;
	this.ySize = 166;

  }
  private static final ResourceLocation texture = new ResourceLocation(Reference.MOD_ID + ":textures/hud/hello.png");

/**
 * Initializes the GUI, sets up buttons and title and directories.
 */
  		@Override
        public void initGui() {
        	//directory = new File(FMLClientHandler.instance().getClient().mcDataDir + "/mods/TimeMod/past/");
        //	directory.mkdir();
        	//directory = new File(FMLClientHandler.instance().getClient().mcDataDir + "/mods/TimeMod/past/" + ms.getWorldName());
        //	files = directory.listFiles(); 
            //i is index
         //   this.localizedWorldText = ("selectWorld.world");
            //Keyboard.enableRepeatEvents(true);
            ////this.buttonList.add(this.buttonSelect = new GuiButton(1, this.width / 2 - 154, this.height - 52, 150, 20, "Travel"));
           // this.buttonList.add(new GuiButton(0, this.width / 2 - 154, this.height - 28, 150, 20, ("Cancel")));
            this.guiLeft = (this.width - 200) / 2;
            this.guiTop = (this.height - 166) / 2;
			Keyboard.enableRepeatEvents(true);
			this.buttonList.clear();
			this.buttonList.add(new GuiButton(0, this.guiLeft + 162, this.guiTop + 33, 20, 20, "+"));
			this.buttonList.add(new GuiButton(1, this.guiLeft + 162, this.guiTop + 60, 20, 20, "-"));
			this.buttonList.add(new GuiButton(2, this.guiLeft + 5, this.guiTop + 4, 60, 20, "CANCEL"));
			this.buttonList.add(new GuiButton(3, this.guiLeft + 166, this.guiTop + 5, 30, 20, "???"));
                    //this.buttonList.add(new GuiButton(3, this.guiLeft + 162,this.guiTop + 33, 20, 20, "+"));
                   // this.buttonList.add(new GuiButton(2, this.guiLeft + 162,this.guiTop + 63, 20, 20,"-"));
                   // this.buttonList.add(new GuiButton(0, this.guiLeft + 69,this.guiTop + 141, 60, 20,"CANCEL"));
                   // this.buttonList.add(new GuiButton(4, this.guiLeft + 12, this.guiTop + 49, 60, 20,"??????"));
                   // this.buttonList.add(new GuiButton(1, this.guiLeft + 69,this.guiTop + 102, 60, 20,"?TRAVEL?"));

            
            //this.timeSlotContainer = new GuiTimeSlot(this);
       //     this.timeSlotContainer.registerScrollButtons(4, 5);
          //  this.loadSaves();
                    //ics = ms.getCommandSenderEntity();
                  //  if(travel==true) travel = false;

        }
        
        @Override
		protected void drawGuiContainerForegroundLayer(int par1, int par2) {
        	
        	// for(File file : files){
          //  String nameOfTime = timeList.toString().valueOf(file.getName());
        	this.fontRenderer.drawString("gas", 11, 36, -1);
			this.fontRenderer.drawString("full", 29, 35, -1);
			this.fontRenderer.drawString("time", 124, 48, -1);

			//this.fontRenderer.drawString("Time"+""+getSelectedWorld()+"", 105, 54, -16777165);
		//}
        }
        
        @Override
		protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        	GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			this.mc.renderEngine.bindTexture(texture);
			int k = (this.width - this.xSize) / 2;
			int l = (this.height - this.ySize) / 2;
			this.drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
			zLevel = 100.0F;
			this.mc.renderEngine.bindTexture(new ResourceLocation(Reference.MOD_ID + ":textures/hud/cllo.png"));
			this.drawTexturedModalRect(this.guiLeft + 108, this.guiTop + 48, 0, 0, 256, 256);


		}
        
        /**
         * Called whenever a button is pressed.  Handles past travel to different zones
         * @param playere 
         */ 
	//	@Override
        	public void actionPerformed(GuiButton gButton) 
        	{
        		if(gButton.id == 2 && getSelectedWorld()>-1)
        		{
        			setSelectedWorld(getSelectedWorld() - 1);
        		}

        		ArrayList timeL = DimensionInit.TimeList;
				if(gButton.id == 3 && getSelectedWorld()<=timeL.size())
        		{
        			setSelectedWorld(getSelectedWorld() + 1);
        		}
        		if(gButton.id == 0)
        		{
        			mc.displayGuiScreen(null);
        		}
        		if(gButton.id == 1)
        		{	
        			
					//String name = mc.player.getName();
					//String name = mc.player.getName();
					//EntityPlayer playere = (EntityPlayer) ics.getCommandSenderEntity();
					//TeleporterTime tt = new TeleporterTime(mc.getIntegratedServer().getWorld(getSelectedWorld()));
					//travel = true;
					//playere.setPortal(playere.getPosition());
					//playere.changeDimension(selectedWorld);
					//mc.getIntegratedServer().getPlayerList().transferPlayerToDimension((EntityPlayerMP) playere, selectedWorld, tt);
                   
					/**String nameOfTime = (this.timeList.get(this.getSelectedWorld(this)).toString());
        			System.out.println(nameOfTime);
        			for(int i = 0; i < files.length; i++)
        			{
        				System.out.println(files[i].toString());
        				if(files[i].toString().contains(nameOfTime)) 
        				{
            				try {
            					
                        		PastMechanics pMechanics = new PastMechanics();
                        		EntityMechanics eMechanics = new EntityMechanics();
                        		
            					WorldClient wc = mc.world;
            					WorldInfo worldi = mc.world.getWorldInfo();
            					
            					String worldName = ms.getWorldName();
            					String folderName = ms.getFolderName();
            					
            					Main.vars.setLastPastTimeSavedForWorld(nameOfTime);
            					//File allEntityData = new File(FMLClientHandler.instance().getClient().mcDataDir +"/mods/TimeMod/past/EntityLocations/" + FMLClientHandler.instance().getServer().getWorldName() + "/" + Main.vars.getPastTime() + ".epd");
            					
            					mc.player.sendChatMessage("Loading...");
            					File present = new File("./saves/" + ms.getWorldName() + "/region").getAbsoluteFile();
            					String fname = "\\mods\\TimeMod\\present\\" + ms.getWorldName();
                            
            					File directory = new File(mc.mcDataDir + fname);
                            
            					CopyFile cp = new CopyFile();           
                     
            					System.out.println("Present: " + present);
            					System.out.println("Directory: " + directory);
            					cp.copyDirectory(present, directory);                 
            					isInPast = true;
            					
            					EntityPlayer player = mc.player;
                        		//pMechanics.loadEntityData();

            					//eMechanics.despawnAllEntities(FMLServerHandler.instance().getServer().worldServerForDimension(0));
            					
            				    mc.world.sendQuittingDisconnectingPacket();
            					mc.loadWorld((WorldClient)null);
            					mc.displayGuiScreen(new GuiMainMenu());
                           
            					source =  new File(FMLClientHandler.instance().getClient().mcDataDir +"/mods/TimeMod/past/" + ms.getWorldName() + "/" + nameOfTime); 
            					staticsource = source;
                            	worldInPast = source;
                            	File dest = new File(FMLClientHandler.instance().getClient().mcDataDir +"/saves/" + ms.getWorldName() + "/region");

                            	try 
                            	{
                    		        if (mc.getSaveLoader().canLoadWorld(worldName))
                    		        {
                                		Thread.sleep(files.length * 750 * 2);
                                		System.out.println(nameOfTime);
                                		System.out.println(source);
                                		System.out.println(source.listFiles());
                                		System.out.println(dest.listFiles());
                                		
                                		CopyFile.moveMultipleFiles(source, dest);
                                		
                                		
                                		mc.launchIntegratedServer(folderName, worldName, (WorldSettings)null);
                    		        }
                            	}
                            catch (Exception ex)
                            {
                            	ex.printStackTrace();
                            }
            			}
            			
            		catch (IOException ex) 
            		{
            			ex.printStackTrace();
            		}
        		}	
        	}
        }
       // else
        {
        // this.timeSlotContainer.actionPerformed(gButton);
       */  }

}
       
        	/*@Override
        	protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException
        	{
        	if (mouseButton == 0) {
        	for (int l = 0; l < this.buttonList.size(); ++l) {
        	GuiButton guibutton = (GuiButton) this.buttonList.get(l);

        	if (guibutton.mousePressed(this.mc, mouseX, mouseY)) {
        	GuiScreenEvent.ActionPerformedEvent.Pre event = new GuiScreenEvent.ActionPerformedEvent.Pre(this, guibutton, this.buttonList);
        	if (MinecraftForge.EVENT_BUS.post(event))
        	break;
        	this.selectedButton = event.getButton();
        	event.getButton().playPressSound(this.mc.getSoundHandler());
        	this.actionPerformed(event.getButton());
        	if (this.equals(this.mc.currentScreen))
        	MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.ActionPerformedEvent.Post(this, event.getButton(), this.buttonList));
        	break; // i had just to add this break :D
        	}
        	}}
        	}
        	*/
        	public boolean doesGuiPauseGame()
        {
                return false;
        }
        	@Override
        public void onGuiClosed() {
        	Keyboard.enableRepeatEvents(false);

        }
        
        /**
         * Draws the screen and all the components in it.
         */
        	@Override
        public void drawScreen(int par1, int par2, float par3)
        {       
        	super.drawScreen(par1, par2, par3);
           // this.timeSlotContainer.drawScreen(par1, par2, par3);
           // this.drawCenteredString(this.fontRenderer, "Travel To...", this.width / 2, 20, 16777215);
        	this.drawDefaultBackground();
			//super.drawScreen(par1, par2, par3);
			this.renderHoveredToolTip(par1, par2);

            
        }        
        //static List getSize(GuiTimetravelContainer par1)
        //{
        //    return par1.timeList;
       // }
        private void loadSaves()
        {
            this.timeList = new ArrayList();
            System.out.println(files);
            if(files != null)
            {
                for(File file : files) {
                	System.out.println(files.length + " " + file.getName());
                	if(!file.getName().contains("Entity"))
                	{
                    	timeList.add(file.getName());
                	}
                }
                this.setSelectedWorld(-1);

            }
        }

		public int getSelectedWorld() {
			return selectedWorld;
		}

		public void setSelectedWorld(int selectedWorld) {
			this.selectedWorld = selectedWorld;
		}

		@Override
		public void updateScreen() {
			super.updateScreen();
		}

		@Override
		protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
			super.mouseClicked(mouseX, mouseY, mouseButton);
		}

		@Override
		protected void keyTyped(char typedChar, int keyCode) throws IOException {
			super.keyTyped(typedChar, keyCode);
		}

		
		
		
		public void writeToNBT(NBTTagCompound nbt) {
			
			
			nbt.setInteger("selectedWorld", selectedWorld);
		}
		
		public void readFromNBT(NBTTagCompound nbt) {
			selectedWorld = nbt.getInteger("selectedWorld");
			
			
		}

       
        
        
}