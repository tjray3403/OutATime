package com.bumblebee3403.oat.util.handlers;

import com.bumblebee3403.oat.util.Reference;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

public class SoundHandler {
	
	





	public static SoundEvent create(String resource) {
		ResourceLocation identifier = new ResourceLocation(Reference.MOD_ID, resource);
		return new SoundEvent(identifier).setRegistryName(identifier);
	}
}