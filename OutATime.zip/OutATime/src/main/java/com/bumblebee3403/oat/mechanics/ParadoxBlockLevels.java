package com.bumblebee3403.oat.mechanics;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;

public class ParadoxBlockLevels
{
    private static final ParadoxBlockLevels extractingBase = new ParadoxBlockLevels();

    /** The list of Blocks Paradox Levels gained upon mining. */
    private Map extractingList = new HashMap();

    /**
     * Used to call methods addSmelting and getSmeltingResult.
     */
    public static final ParadoxBlockLevels paradoxAmountsForBlocks()
    {
        return extractingBase;
    }

    private ParadoxBlockLevels()
    {
        this.addBlockParadoxLevel(Blocks.WATER, 10);
        this.addBlockParadoxLevel(Blocks.LAVA, 15);
        this.addBlockParadoxLevel(Blocks.GOLD_ORE, 40);
        this.addBlockParadoxLevel(Blocks.IRON_ORE, 25);
        this.addBlockParadoxLevel(Blocks.COAL_ORE, 10);
        this.addBlockParadoxLevel(Blocks.LAPIS_ORE, 30);
        this.addBlockParadoxLevel(Blocks.DIAMOND_ORE, 70);
        this.addBlockParadoxLevel(Blocks.REDSTONE_ORE, 40);
        this.addBlockParadoxLevel(Blocks.EMERALD_ORE, 60);
        this.addBlockParadoxLevel(Blocks.COBBLESTONE, 1);
        this.addBlockParadoxLevel(Blocks.OBSIDIAN, 7);
        this.addBlockParadoxLevel(Blocks.DISPENSER, 25);
        this.addBlockParadoxLevel(Blocks.PISTON, 45);
        this.addBlockParadoxLevel(Blocks.TNT, 30);
        this.addBlockParadoxLevel(Blocks.BOOKSHELF, 20);
        this.addBlockParadoxLevel(Blocks.MOSSY_COBBLESTONE, 5);
        this.addBlockParadoxLevel(Blocks.CHEST, 30);
        this.addBlockParadoxLevel(Blocks.REDSTONE_WIRE, 8);
        this.addBlockParadoxLevel(Blocks.FURNACE, 25);
        this.addBlockParadoxLevel(Blocks.GLASS, 10);
        this.addBlockParadoxLevel(Blocks.CAULDRON, 50);
        this.addBlockParadoxLevel(Blocks.END_PORTAL_FRAME, 100);
        this.addBlockParadoxLevel(Blocks.GLOWSTONE, 15);
        this.addBlockParadoxLevel(Blocks.QUARTZ_ORE, 9);
        this.addBlockParadoxLevel(Blocks.DRAGON_EGG, 999);
        this.addBlockParadoxLevel(Blocks.ANVIL, 27);
        this.addBlockParadoxLevel(Blocks.BEACON, 80);
        this.addBlockParadoxLevel(Blocks.ENDER_CHEST, 60);
        this.addBlockParadoxLevel(Blocks.ENCHANTING_TABLE, 50);
        this.addBlockParadoxLevel(Blocks.BREWING_STAND, 40);
        this.addBlockParadoxLevel(Blocks.BED, 30);
        this.addBlockParadoxLevel(Blocks.CAKE, 110);
        this.addBlockParadoxLevel(Blocks.COAL_BLOCK, 50);
        this.addBlockParadoxLevel(Blocks.DIAMOND_BLOCK, 120);
        this.addBlockParadoxLevel(Blocks.EMERALD_BLOCK, 90);
        this.addBlockParadoxLevel(Blocks.GOLD_BLOCK, 70);
        this.addBlockParadoxLevel(Blocks.IRON_BLOCK, 60);
        this.addBlockParadoxLevel(Blocks.LAPIS_BLOCK, 60);
        this.addBlockParadoxLevel(Blocks.QUARTZ_BLOCK, 50);
        this.addBlockParadoxLevel(Blocks.REDSTONE_BLOCK, 50);
        this.addBlockParadoxLevel(Blocks.SKULL, 60);
     //   this.addBlockParadoxLevel(TimeTraveler.paradoxCondenser, 40);
      ///  this.addBlockParadoxLevel(TimeTraveler.collisionBlock, 999);
      //  this.addBlockParadoxLevel(TimeTraveler.paradoxExtractor, 50);
      //  this.addBlockParadoxLevel(TimeTraveler.timeTravel, 999);
      //  this.addBlockParadoxLevel(TimeTraveler.travelTime, 30);
    }

    /**
     * Adds a block's paradox level upon mining.
     */
    public void addBlockParadoxLevel(Block par1, int par3)
    {
        this.extractingList.put(par1, par3);
    }

    public Map getParadoxBlockLevelList()
    {
        return this.extractingList;
    }
}
