package com.bumblebee3403.oat.util.handlers;



import com.bumblebee3403.oat.entity.EntityPlayerPast;
import com.bumblebee3403.oat.entity.EntityTimecart;
import com.bumblebee3403.oat.entity.render.RenderEntityPlayerPast;
import com.bumblebee3403.oat.entity.render.RenderTimecart;

import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class RenderHandler {
	
	public static void registerEntityRenderers() {
		
		
		
		RenderingRegistry.registerEntityRenderingHandler(EntityPlayerPast.class, new IRenderFactory<EntityPlayerPast>()
		{

			@Override
			public Render<? super EntityPlayerPast> createRenderFor(RenderManager manager) {
				// TODO Auto-generated method stub
				return new RenderEntityPlayerPast(manager);
			}
	
		});

		RenderingRegistry.registerEntityRenderingHandler(EntityTimecart.class, new IRenderFactory<EntityTimecart>()
		{

			@Override
			public Render<? super EntityTimecart> createRenderFor(RenderManager manager) {
				// TODO Auto-generated method stub
				return new RenderTimecart(manager);
			}
	
		});

		
		
				
	}

}
