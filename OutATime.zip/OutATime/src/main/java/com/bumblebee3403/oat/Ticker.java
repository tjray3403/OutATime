package com.bumblebee3403.oat;

import java.io.File;
import java.util.EnumSet;

import com.bumblebee3403.oat.gui.GuiTimeTravel;
import com.bumblebee3403.oat.mechanics.CopyFile;
import com.bumblebee3403.oat.pasttravel.PastMechanics;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.Potion;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.PlayerTickEvent;


/**
 * Ticker
 * @author Charsmud
 *
 */
public class Ticker 
{
	public int ctr;
	public int ct;
	public int count;
	
	public static int paradoxLevel;
	
	public static int minutes = 2;
	public static int seconds = 1;
	
	public int invisPotTime = 0;
	public int sneakTime = 0;
	
	private int timeNumber = 1;
	private int pathFileLine = 0;
	private int hunterSpawn = 0;

	String text;

	CopyFile copyFile = new CopyFile();

	public boolean hasInitRun = false;
	public boolean hasInitMobs = false;
	
	private boolean mobsInitSpawned = false; 
	private boolean isInPast;
	private boolean hasRun = false;

	
	@SubscribeEvent
	public void onPlayerTick(PlayerTickEvent event)
	{
		if(event.side.isClient())
		{
			paradoxLevel = Main.vars.getParadoxAmt();

			Minecraft mc = Minecraft.getMinecraft();
			ctr++;
			ct++;
			//System.out.println(ctr);
			hasInitRun = (new File(mc.mcDataDir + "/mods/TimeMod/past/" + FMLClientHandler.instance().getServer().getWorldName())).exists();


			PastMechanics mechanics = new PastMechanics();
			
		    text  = "Time Remaining: " + minutes + " Minute, " + seconds + " Seconds";

			isInPast = GuiTimeTravel.isInPast;		
			if(!isInPast && !Main.vars.getIsInFuture())
			{
				Main.vars.setIsSpawnedPastPlayer(false);
				if(event.player.isSneaking())
				{
				}
				if(paradoxLevel >= 30)
				{
					hunterSpawn++;
					if(hunterSpawn == 150)
					{
				//		mechanics.spawnParadoxHunter(mc.getIntegratedServer(), mc);
						System.out.println("Spawned Paradox Hunter!");
						hunterSpawn = 0;
					}
				}
			}
			
			if(ct == 20)
			{
				if(!isInPast && !Main.vars.getIsInFuture())
				{				
					ct = 0;
				}
			}
			
			if(ctr == 2400)
			{
				if(!isInPast && !Main.vars.getIsInFuture())
				{
					mechanics.saveTime(mc.getIntegratedServer(), mc, copyFile);
					mechanics.beginPastRecording(event.player, event.player.getDisplayName().getFormattedText());
					mechanics.beginPastRecording(event.player, event.player.getDisplayName().getFormattedText());

				}
				ctr = 0;
			}
			if(!hasInitRun)
			{
				hasInitRun = true;
				mechanics.firstTime(mc.getIntegratedServer(), mc);
				mechanics.saveTime(mc.getIntegratedServer(), mc, copyFile);
			}
			if(!hasRun)
			{
				hasRun = true;
				mechanics.beginPastRecording(event.player, event.player.getDisplayName().getFormattedText());

			}
			if(isInPast)
			{	
				if(!Main.vars.getIsSpawnedPastPlayer())
				{
					mechanics.replayPast(event.player);
					Main.vars.setIsSpawnedPastPlayer(true);
				}
				if(Main.vars.getNextSet())
				{

				}
				count++;
				if(paradoxLevel < 0)
				{
					paradoxLevel = 0;
				}
				if(paradoxLevel <= 128)
				{
					if(event.player.isPotionActive(MobEffects.INVISIBILITY))
					{
						invisPotTime++;
						if(invisPotTime == 10)
						{
							paradoxLevel = paradoxLevel - 5;
							invisPotTime = 0;
						}
					}
					if(event.player.isSneaking())
					{
						sneakTime++;
						if(sneakTime == 30)
						{
							paradoxLevel = paradoxLevel - 2;
							sneakTime = 0;
						}
					}
				}
				else
				{

					mechanics.returnToPresent(mc, paradoxLevel, mc.getIntegratedServer());
					mobsInitSpawned = false;
					isInPast = false;
					Main.vars.setNextSet(true);
				}
			}
			if(isInPast)
			{
				if(count == 20)
				{
					seconds--;
					count = 0;
				}
				if(seconds == 0)
				{
					minutes--;
					seconds = 60;
				}
				if(minutes == 0)
				{
					text = "Time Remaining: " + seconds + " Seconds";
				}
				if(minutes <= 0 && seconds <= 1)
				{
					mechanics.outOfTime(mc, mc.getIntegratedServer(), text);
					mobsInitSpawned = false;
					isInPast = false;
					Main.vars.setNextSet(true);

				}
			}	
			Main.vars.setParadoxAmt(paradoxLevel);

		}
	}
	@SubscribeEvent
	public void onRenderTick(TickEvent.RenderTickEvent event)
	{
		Minecraft mc = FMLClientHandler.instance().getClient();
		PastMechanics mechanics = new PastMechanics();

        if(mc.currentScreen == null)
        {
        	if(isInPast)
        	{
			//	mechanics.drawTimeTicker(mc, text);
        	}
    		//mechanics.updateParadoxBar(mc, paradoxLevel);
        }

	}
}
