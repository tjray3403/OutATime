package com.bumblebee3403.oat.entity;

import com.bumblebee3403.oat.Main;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIBreakDoor;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;

public class EntityParadoxHunter extends EntityMob 
{
	public EntityParadoxHunter(World par1World)
	{
		super(par1World);
		//this.t = "/mods/Charsmud_TimeTraveler/textures/mobs/ParadoxHunter.png";
		this.setAIMoveSpeed(2.0F);
        this.tasks.addTask(2, new EntityAIAttackMelee(this, 1.0D, false));
        this.tasks.addTask(6, new EntityAIWander(this, 1.0D));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, true));

	}
	public int getAttackStrength(Entity par1Entity) 
	{
		return 20;
	}

	protected boolean isAIEnabled()
	{
		return true;
	}
	public String getTexture()
    {
		return "/assets/charsmud_timetraveler/textures/mobs/ParadoxHunter.png";
    }
	public int getTotalArmorValue()
    {
        return 20;
    }
	
	 protected SoundEvent getStepSound()
	    {
	        return SoundEvents.ENTITY_ZOMBIE_STEP;
	    }

    protected void dropRareDrop(int par1)
    {
        switch (this.rand.nextInt(1))
        {
            case 0:
              //  this.dropItem(Main.condensedParadox, 1);
                break;
        }
    }

	
	public void onLivingUpdate()
    {
		//BURNS THE MOB IF ITS DAYTIME AND IS IN THE SUN
        /*if (this.worldObj.isDaytime() && !this.worldObj.isRemote)
        {
            float var1 = this.getBrightness(1.0F);

            if (var1 > 0.5F && this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && this.rand.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F)
            {
                this.setFire(8);
            }
        }*/

        super.onLivingUpdate();
    }


}