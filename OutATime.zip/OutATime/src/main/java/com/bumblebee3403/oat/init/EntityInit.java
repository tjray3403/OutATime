package com.bumblebee3403.oat.init;

import com.bumblebee3403.oat.Main;
import com.bumblebee3403.oat.entity.EntityChair;
import com.bumblebee3403.oat.entity.EntityParadoxHunter;
import com.bumblebee3403.oat.entity.EntityPlayerPast;
import com.bumblebee3403.oat.entity.EntityTimecart;
import com.bumblebee3403.oat.util.Reference;

import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;

public class EntityInit {
	
	public static void registerEntities(){
		
		registerEntityButWithNoEgg("34playerpast", EntityPlayerPast.class, Reference.ENTITY_PLAYER_PAST, 50);
		registerEntityButWithNoEgg("34paradoxhunter", EntityParadoxHunter.class, Reference.ENTITY_PARADOX_HUNTER, 50);
		//registerEntityButWithNoEgg("34playerpast", EntityPlayerPast.class, Reference.ENTITY_XP_ORB_TT, 50);
		registerEntityButWithNoEgg("34chair", EntityChair.class, Reference.ENTITY_CHAIR, 50);
		registerEntity("34timecart", EntityTimecart.class, Reference.ENTITY_TIMECART, 50, 5754, 86345);

		
	}
	
	
	
	private static void registerEntity(String name , Class<? extends Entity> entity, int id, int range, int color1, int color2){
		EntityRegistry.registerModEntity(new ResourceLocation(Reference.MOD_ID + ":" + name), entity, name, id, Main.instance, range, 1, true, color1, color2);
		
	}
	
	private static void registerEntityButWithNoEgg(String name , Class<? extends Entity> entity, int id, int range){
		EntityRegistry.registerModEntity(new ResourceLocation(Reference.MOD_ID + ":" + name), entity, name, id, Main.instance, range, 1, true);
		
	}

}
