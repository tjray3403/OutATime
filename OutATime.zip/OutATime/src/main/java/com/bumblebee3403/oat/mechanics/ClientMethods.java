package com.bumblebee3403.oat.mechanics;

import net.minecraft.server.MinecraftServer;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class ClientMethods
{
	public static boolean isSinglePlayer()
	{
		try
		{
			if(FMLCommonHandler.instance().getMinecraftServerInstance().isServerRunning())
			{
				return true;
			}
			return false;
		}
		catch(Exception ex)
		{
			return false;
		}
	}
}
