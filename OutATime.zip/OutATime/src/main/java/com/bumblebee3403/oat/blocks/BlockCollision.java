package com.bumblebee3403.oat.blocks;

import java.util.List;

import com.bumblebee3403.oat.Main;
import com.bumblebee3403.oat.blocks.tileentity.TileEntityCollision;
import com.bumblebee3403.oat.blocks.tileentity.TileEntityTimeMachine;
import com.bumblebee3403.oat.entity.EntityChair;
import com.bumblebee3403.oat.util.Reference;

import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


public class BlockCollision extends BlockBase implements ITileEntityProvider
{

	public BlockCollision(String name,Material material)
	{
		super(name, material);
		this.setBlockUnbreakable();
	}

	@Override
    public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
	{
		TileEntityCollision tileEntity = (TileEntityCollision)worldIn.getTileEntity(pos);
		String operator = tileEntity.operator;
		tileEntity.operatorFunctions(operator);
		return false;
	}
	}
	// This block is called when block is broken and destroys the primary block.
	
	@Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
		TileEntityTimeMachine tetm = (TileEntityTimeMachine) worldIn.getTileEntity(pos);
		//InventoryHelper.dropInventoryItems(worldIn, pos, (IInventory) tetm);
		super.breakBlock(worldIn, pos, state);
		
		TileEntityCollision tileEntity = (TileEntityCollision) worldIn.getTileEntity(pos);
		// If not make this check, the game may crash if there's no tile entity
		// at i, j, k.
		if (tileEntity != null)
		{
			System.out.println("IN HERE");
			worldIn.setBlockToAir(new BlockPos(tileEntity.primary_x, tileEntity.primary_y, tileEntity.primary_z));
			worldIn.removeTileEntity(new BlockPos(tileEntity.primary_x, tileEntity.primary_y, tileEntity.primary_z));
			
			int i;
			int j;
			int k;
			List<Entity> entitiesToSlow = worldIn.getEntitiesWithinAABB(Entity.class, this.getBoundingBox(state, worldIn, pos));
			if(entitiesToSlow.size() > 0)
			{
				for(int r = 0; r < entitiesToSlow.size(); r++)
				{
					Entity e = entitiesToSlow.get(r);
					System.out.println(e);

					if(e instanceof EntityChair)
					{
						e.setDead();
					}
				}
			}		
		}
		worldIn.removeTileEntity(pos);
	}

	@Override
    public void onNeighborChange(IBlockAccess world, BlockPos pos, BlockPos neighbor)
	{
	
		TileEntityCollision tileEntity = (TileEntityCollision) world.getTileEntity(pos);
		if (tileEntity != null) 
		{
			if (world.isAirBlock(new BlockPos(tileEntity.primary_x, tileEntity.primary_y, tileEntity.primary_z))) 
			{
				((World) world).setBlockToAir(pos);
				((World) world).removeTileEntity(pos);
			}
		}
	}

	// This makes our gag invisible.
	@Override
	public boolean doesSideBlockRendering(IBlockState state, IBlockAccess world, BlockPos pos, EnumFacing face)
    {
        return false;
    }

	// This tells minecraft to render surrounding blocks.
	@Override
	public boolean isOpaqueCube(IBlockState state)
    {
        return false;
    }

	@Override
	public TileEntity createNewTileEntity(World world, int metadata) {
		return new TileEntityCollision();
	}
/**
	@SideOnly(Side.CLIENT)
	@Override
	public void registerBlockIcons(IIconRegister par1IconRegister) {
		this.blockIcon = par1IconRegister.registerIcon(Reference.MOD_ID + ":"
				+ ("collisionBlock"));
	}*/
}