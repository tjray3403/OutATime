package com.bumblebee3403.oat.init;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import com.bumblebee3403.oat.Main;
import com.bumblebee3403.oat.dimension.DimensionProperties;

import com.bumblebee3403.oat.futuretravel.WorldProviderFuture;
import org.apache.commons.io.FileUtils;

import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.DimensionType;
import net.minecraftforge.common.DimensionManager;
import java.util.Map.Entry;
import java.util.logging.Logger;


public class DimensionInit {
	
	private HashMap<Integer,DimensionProperties> dimensionList;
	private DimensionProperties overworldProperties;
	private boolean hasBeenInitiallized;
	private static DimensionManager instance = new DimensionManager();
	//public static final String workingPath = "Oat";
	public static final String tempFile = "/temp.dat";
	public static final String worldXML = "/TimeDefs.xml";
	private static int dimId;
	public static final ArrayList TimeList = new ArrayList();
	public static final DimensionType Future = DimensionType.register("Future", "_future", dimId, WorldProviderFuture.class, false);
	public static final DimensionType Past = DimensionType.register("Past", "_past", Main.pastdimensionId, WorldProviderFuture.class, false);
	public static int dimOffset = 0;
	

	
	
	public static void registerDimension() {
		DimensionManager.registerDimension(Main.dimensionId, Future);
		NewPastDim(3);
	}
	
	
	public Integer[] getRegisteredDimensions() {
		Integer ret[] = new Integer[dimensionList.size()];
		return dimensionList.keySet().toArray(ret);
	}

	/**
	 * @return List of dimensions registered with this manager that are currently loaded on the server/integrated server
	 */
	public Integer[] getLoadedDimensions() {
		return getRegisteredDimensions();
	}

	
	
	
	
	
	public static void NewPastDim(int dim) {		
		 dimId = dim;
		
		//DimensionType Past = DimensionType.register("Past"+""+dimId+"", "_past"+""+dimId+"", dimId, WorldProviderFuture.class, false);;
		DimensionManager.registerDimension(dimId, Past);
		TimeList.add(dimId);
		
		
		 //getdim(dimId);
		
		
	}


	public ArrayList getTimeList() {
		return TimeList;
		// TODO Auto-generated method stub
		
	}
	
	
	
	}

	
