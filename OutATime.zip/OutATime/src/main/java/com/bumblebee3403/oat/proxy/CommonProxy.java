package com.bumblebee3403.oat.proxy;

import net.minecraft.item.Item;

public class CommonProxy {
	
	
	
	public void registerItemRenderer(Item item, int meta, String id) {
		
	}
	
	
}
