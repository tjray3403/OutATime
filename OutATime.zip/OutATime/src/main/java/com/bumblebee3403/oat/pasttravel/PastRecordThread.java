package com.bumblebee3403.oat.pasttravel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.List;

import com.bumblebee3403.oat.Main;

import net.minecraft.block.Block;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.EntityEquipmentSlot.Type;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.NonNullList;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;

class PastRecordThread implements Runnable 
{
	public Thread t;
    private static final DataParameter<Byte> SOMETHING = EntityDataManager.<Byte>createKey(EntityPlayer.class, DataSerializers.BYTE);
	EntityPlayer player;
	public Boolean capture = Boolean.valueOf(false);
	RandomAccessFile in;
	Boolean lastTickSwipe = Boolean.valueOf(false);
	//ItemStack itemsEquipped;
    public final NonNullList<ItemStack> armorInventorye = NonNullList.<ItemStack>withSize(4, ItemStack.EMPTY);
	List<PastAction> eventList;
	private ItemStack itemsEquipped;

	PastRecordThread(EntityPlayer _player, String capname)
	{
		try {
			File f = new File(FMLClientHandler.instance().getClient().mcDataDir , "/mods/TimeMod/past/EntityLocations/" + FMLCommonHandler.instance().getMinecraftServerInstance().getWorldName() + "/");
			if(!f.exists())
			{
				f.mkdirs();
			}
			int counter = f.list().length + 1;
			String time = "Time " + (String.format("%03d",counter));			
			File file = new File(FMLClientHandler.instance().getClient().mcDataDir + "/mods/TimeMod/past/EntityLocations/" + FMLCommonHandler.instance().getMinecraftServerInstance().getWorldName() + "/" + time);
			if (!file.exists()) 
			{
				file.mkdirs();
			}
			this.in = new RandomAccessFile(file.getAbsolutePath() + "/" + capname + ".ppd", "rw");

			this.in.setLength(0L);
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		this.player = _player;
		this.capture = Boolean.valueOf(true);
		this.eventList = Main.instance.getActionListForPlayer(this.player);
		this.t = new Thread(this, "TimeTraveler Past Record Thread");

		this.t.start();
	}

	public void run()
	{
		try
		{
			this.in.writeShort(60651);
			while (this.capture.booleanValue())
			{
				trackAndWriteMovement();

				trackSwing();

				trackHeldItem();

				trackArmor();

				writeActions();

				Thread.sleep(100L);
				if (this.player.isDead) 
				{
					this.capture = Boolean.valueOf(false);
					Main.instance.recordThreads.remove(this.player);
					System.out.println("Stopped recording " + this.player.getDisplayName() + ".  RIP.");
				}
			}
			this.in.close();
		}
		catch (InterruptedException e) 
		{
			System.out.println("Child interrupted.");
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		System.out.println("Exiting child thread.");
	}

	private void trackAndWriteMovement() throws IOException 
	{
		in.writeFloat(player.rotationYaw);
		in.writeFloat(player.rotationPitch);
		in.writeDouble(player.posX);
		in.writeDouble(player.posY - 1.5);
		in.writeDouble(player.posZ);
		in.writeDouble(player.motionX);
		in.writeDouble(player.motionY);
		in.writeDouble(player.motionZ);
		in.writeFloat(player.fallDistance);
		in.writeBoolean(player.isAirBorne);
		in.writeBoolean(player.isSneaking());
		in.writeBoolean(player.isSprinting());
		in.writeBoolean(player.onGround);
		in.writeBoolean((player.getDataManager().get(SOMETHING) & 1 << 4) != 0);
	}

	private void trackArmor()
	{
		EntityEquipmentSlot ci = itemsEquipped.getItem().getEquipmentSlot(itemsEquipped);
			//for (EntityEquipmentSlot ci = 1; ci < 5; ci++)
		//{
			if (this.player.getEquipmentAndArmor()/*[ci - 1]*/ != null)
			{
				Iterable<ItemStack> itemsEquippted = player.getArmorInventoryList();
				if (player.getArmorInventoryList()/*[ci - 1]*/ != itemsEquippted) {
					itemsEquipped = player.getItemStackFromSlot(ci);	
					PastAction ma = new PastAction(PastActionTypes.EQUIP);
					ma.armorSlot = ci;
					ma.armorId = Item.getIdFromItem(itemsEquipped.getItem());
					ma.armorDmg = itemsEquipped.getItemDamage();

					this.eventList.add(ma);
				}
			} 
			else if (this.itemsEquipped != null) 
			{
				this.itemsEquipped = null;
				PastAction ma = new PastAction(PastActionTypes.EQUIP);
				ma.armorSlot = ci;
				ma.armorId = Item.getIdFromItem(itemsEquipped.getItem());
				ma.armorDmg = 0;
				this.eventList.add(ma);
			}
		}
	//}

	private void trackHeldItem()
	{
		if (this.player.getHeldItemMainhand() != null)
		{
			if (player.getHeldItemMainhand() != itemsEquipped)
			{
				itemsEquipped = player.getHeldItemMainhand();
				PastAction ma = new PastAction(PastActionTypes.EQUIP);
				ma.armorSlot = null;
				ma.armorId = Item.getIdFromItem(itemsEquipped.getItem());
				ma.armorDmg = this.player.getHeldItemMainhand().getItemDamage();
				player.getHeldItemMainhand().writeToNBT(ma.itemData);
				this.eventList.add(ma);
			}
		} 
		else if (this.itemsEquipped != null)
		{
			this.itemsEquipped = null;
			PastAction ma = new PastAction(PastActionTypes.EQUIP);
			ma.armorSlot = null;
			ma.armorId = Item.getIdFromItem(itemsEquipped.getItem());
			ma.armorDmg = 0;
			this.eventList.add(ma);
		}
	}

	private void trackSwing() 
	{
		if (this.player.isSwingInProgress)
		{
			if (!this.lastTickSwipe.booleanValue())
			{
				this.lastTickSwipe = Boolean.valueOf(true);
				this.eventList.add(new PastAction(PastActionTypes.SWIPE));
			}
		}
		else 
		{
			this.lastTickSwipe = Boolean.valueOf(false);
		}
	}

	private void writeActions() throws IOException 
	{
		if (this.eventList.size() > 0) 
		{
			this.in.writeBoolean(true);
			PastAction ma = (PastAction) this.eventList.get(0);
			this.in.writeByte(ma.type);
			switch (ma.type) 
			{
			case PastActionTypes.CHAT:
			{
				this.in.writeUTF(ma.message);
				break;
			}
			case PastActionTypes.SWIPE:
			{
				break;
			}
			case PastActionTypes.DROP:
			{
				CompressedStreamTools.write(ma.itemData, this.in);
				break;
			}
			case PastActionTypes.EQUIP:
			{
				
				this.in.writeUTF(ma.armorSlot.getName());
				this.in.writeInt(ma.armorId);
				this.in.writeInt(ma.armorDmg);
				
				if (ma.armorId != -1) {
					CompressedStreamTools.write(ma.itemData, in);
				}
				break;
			}
			case PastActionTypes.SHOOTARROW:
			{
				this.in.writeInt(ma.arrowCharge);
				break;
			}
			case PastActionTypes.PLACEBLOCK: 
			{
				in.writeInt(ma.xCoord);
				in.writeInt(ma.yCoord);
				in.writeInt(ma.zCoord);
				CompressedStreamTools.write(ma.itemData, in);
				break;
			}
			case PastActionTypes.LOGOUT:
			{
				Main.instance.recordThreads.remove(this.player);
				System.out.println("Stopped recording " + this.player.getDisplayName() + ".  Bye!");
				this.capture = Boolean.valueOf(false);
				break;
			}
			case PastActionTypes.BREAKBLOCK:
			{
				in.writeInt(ma.xCoord);
				in.writeInt(ma.yCoord);
				in.writeInt(ma.zCoord);
			}
			}
			this.eventList.remove(0);
		} 
		else 
		{
			this.in.writeBoolean(false);
		}
	}
}
