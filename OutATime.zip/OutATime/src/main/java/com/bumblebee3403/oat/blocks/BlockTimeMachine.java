package com.bumblebee3403.oat.blocks;

import java.util.Random;

import com.bumblebee3403.oat.Main;
import com.bumblebee3403.oat.blocks.tileentity.TileEntityCollision;
import com.bumblebee3403.oat.blocks.tileentity.TileEntityTimeMachine;
import com.bumblebee3403.oat.dimension.TeleporterTime;
import com.bumblebee3403.oat.entity.EntityChair;
import com.bumblebee3403.oat.gui.GuiTimeTravel;
import com.bumblebee3403.oat.init.BlockInit;
import com.bumblebee3403.oat.util.Reference;

import net.minecraft.block.Block;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;

public class BlockTimeMachine extends BlockBase implements ITileEntityProvider{
	
	//public static final PropertyDirection FACING = BlockHorizontal.FACING;
	//public static final PropertyBool POWERED = PropertyBool.create("powered");
	public static final AxisAlignedBB TimeMachineAABB = new AxisAlignedBB(-0.7, 0, -0.7, 1.7, 2.2, 1.7);

	public BlockTimeMachine(String name, Material material) {
		super(name, Material.IRON);
		this.setSoundType(SoundType.METAL);
		//this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
		  
	}
	
	
	public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state,EntityLivingBase entity) {
		super.onEntityCollidedWithBlock(worldIn, pos, state, entity);
		
	//	GuiTimeTravel gtt = new GuiTimeTravel();
	///	gtt.travel = true;
		//TeleporterTime tt = new TeleporterTime(worldIn.getMinecraftServer().getWorld(gtt.getSelectedWorld()));
	//	if(gtt.travel==true){
		//entity.setPortal(entity.getPosition());
	//	entity.changeDimension(gtt.getSelectedWorld(), tt);}
	}
	
	//@Override
	//public Item getItemDropped(IBlockState state, Random rand, int fortune) {
	//	return Item.getItemFromBlock(BlockInit.Block_time_machine);
	//}
	
	@Override
    public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
		if(!playerIn.isRiding()){
		EntityChair ec = new EntityChair(worldIn);
		ec.setPosition(pos.getX(), pos.getY(), pos.getZ());
		worldIn.spawnEntity(ec);
		playerIn.startRiding(ec);
		}
		//GuiTimeTravel gtt = new GuiTimeTravel();
		//if(!worldIn.isRemote) {
		//playerIn.openGui(Main.instance, Reference.GUI_TIME_TRAVEL, worldIn, pos.getX(), pos.getY(), pos.getZ());
		//	Minecraft.getMinecraft().displayGuiScreen(new GuiTimeTravel());
	//	playerIn.setPortal(playerIn.getPosition());
	//	playerIn.changeDimension(gtt.getSelectedWorld());
		//}
		
		
		return true;
		
	}
	
	@Override
	public boolean isPassable(IBlockAccess worldIn, BlockPos pos) { 
		return true;
	}

	
	@Override
	public void onBlockAdded(World worldIn, BlockPos pos, IBlockState state) {
		super.onBlockAdded(worldIn, pos, state);
		
		/*
		 for(int i = -1; i < 2; i++)
	        {
	        	for(int j = 0; j < 3; j++)
	        	{
	        		for(int k = -1; k < 2; k++)
	        		{
	        			if((i == 0 && j == 0 && k == 0) || (i == 0 && j == 1 && k == 0))
	        			{
	        			}
	        			else
	        			{
	        				System.out.println("ADDING");
	        				int x = pos.getX();
							int y = pos.getY();
							int z = pos.getZ();
							worldIn.setBlockState(new BlockPos(x + i, y + j, z + k), BlockInit.Block_collision.getDefaultState(),3);
	            	        TileEntityCollision collisionTile = (TileEntityCollision)worldIn.getTileEntity(new BlockPos(x + i, y + j, z + k));

	            	        if(collisionTile != null)
	            	        {
	                	        collisionTile.primary_x = x;
	                            collisionTile.primary_y = y;
	                            collisionTile.primary_z = z;
	                            collisionTile.operator = "tt";
	            	        }
	        			}
	        		}
	        	}
	        }
		
		
	/*
		if(!worldIn.isRemote) {

		IBlockState north = worldIn.getBlockState(pos.north());
		IBlockState south = worldIn.getBlockState(pos.south());
		IBlockState east = worldIn.getBlockState(pos.east());
		IBlockState west = worldIn.getBlockState(pos.west());
		EnumFacing face =  (EnumFacing)state.getValue(FACING);

		if(face== EnumFacing.NORTH && north.isFullBlock() && !south.isFullBlock()) face = EnumFacing.SOUTH; 
		else if(face== EnumFacing.SOUTH && south.isFullBlock() && !north.isFullBlock()) face = EnumFacing.NORTH; 
		else if(face== EnumFacing.WEST && west.isFullBlock() && !east.isFullBlock()) face = EnumFacing.EAST; 
		else if(face== EnumFacing.EAST && east.isFullBlock() && !west.isFullBlock()) face = EnumFacing.WEST; 
		worldIn.setBlockState(pos, state.withProperty(FACING, face), 2);

		
		
		
	
	
	}*/
		
		
		
		
		
	
	}
	
	@Override
	public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess access, BlockPos pos) {
		return TimeMachineAABB;
		
	}
/*	
	public static void setState(boolean active, World worldIn, BlockPos pos) {
		IBlockState state = worldIn.getBlockState(pos);
		TileEntity tileentity = worldIn.getTileEntity(pos);
		
	if(active) worldIn.setBlockState(pos, BlockInit.Block_time_machine.getDefaultState().withProperty(FACING, state.getValue(FACING)).withProperty(POWERED, true), 3);
	else worldIn.setBlockState(pos, BlockInit.Block_time_machine.getDefaultState().withProperty(FACING, state.getValue(FACING)).withProperty(POWERED, false), 3);
	
		
	if(tileentity!=null) {
		tileentity.validate();
		worldIn.setTileEntity(pos, tileentity);
		
	}
	
	
		
	}
*/

	@Override
	public TileEntity createNewTileEntity(World worldIn, int meta) {
		// TODO Auto-generated method stub
		return new TileEntityTimeMachine();
	}
	
	/*
	@Override
	public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer)
    {
        return this.getDefaultState().withProperty(FACING, placer.getHorizontalFacing().getOpposite());
    }
	
	@Override
	public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
    {
		worldIn.setBlockState(pos, this.getDefaultState().withProperty(FACING, placer.getHorizontalFacing().getOpposite()), 2);
    }
	*/
	
	@Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
		TileEntityTimeMachine tetm = (TileEntityTimeMachine) worldIn.getTileEntity(pos);
		//InventoryHelper.dropInventoryItems(worldIn, pos, (IInventory) tetm);
		super.breakBlock(worldIn, pos, state);
		
	}

	/*
	@Override
	public EnumBlockRenderType getRenderType(IBlockState state) {
		return EnumBlockRenderType.MODEL;
		
	}
	
	@Override
	public IBlockState withRotation(IBlockState state, Rotation rot) {
		return state.withProperty(FACING, rot.rotate((EnumFacing)state.getValue(FACING)));

	}
	
	@Override
	public IBlockState withMirror(IBlockState state, Mirror mirror) {
		
		
		return state.withRotation(mirror.toRotation((EnumFacing)state.getValue(FACING)));
	}
	
	
	@Override
	protected BlockStateContainer createBlockState() {
		
		return new BlockStateContainer(this, new IProperty[] {POWERED, FACING});
	}
	
	@Override
	public IBlockState getStateFromMeta(int meta) {
		EnumFacing facing = EnumFacing.getFront(meta);
		if(facing.getAxis() == EnumFacing.Axis.Y) facing = EnumFacing.NORTH;
		return this.getDefaultState().withProperty(FACING, facing);
	}
	
	@Override
	public int getMetaFromState(IBlockState state) {
		return ((EnumFacing)state.getValue(FACING)).getIndex();
		
	}
	*/
	@Override
	public boolean isOpaqueCube(IBlockState state) {
		return false;
	}
	
	@Override
	public boolean isFullCube(IBlockState stat) {
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
