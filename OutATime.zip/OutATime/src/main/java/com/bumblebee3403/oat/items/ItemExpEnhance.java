package com.bumblebee3403.oat.items;

public class ItemExpEnhance extends ItemBase {

	public ItemExpEnhance(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
