package com.bumblebee3403.oat.dimension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeManager;
import net.minecraftforge.common.BiomeManager.BiomeEntry;

public class DimensionProperties implements Cloneable {

	


	

	private int TimeId = 0;
	//True if dimension is managed and created by AR (false otherwise)
	public boolean isNativeDimension;
	//Gas giants DO NOT need a dimension registered to them
	public float[] skyColor;
	public float[] fogColor;
	
	private String name;
	public float[] sunriseSunsetColors;
	//public ExtendedBiomeProperties biomeProperties;
	private LinkedList<BiomeEntry> allowedBiomes;
	private LinkedList<BiomeEntry> terraformedBiomes;
	private boolean isRegistered = false;
	private boolean isTerraformed = false;
	public boolean hasRings = false;
	public List<ItemStack> requiredArtifacts;



	//Satallites
	
	private IBlockState oceanBlock;
	private IBlockState fillerBlock;
	private int sealevel;
	private int generatorType;

	public DimensionProperties(int id) {
		name = "Temp";
		resetProperties();
		oceanBlock = null;
		fillerBlock = null;
		TimeId = id;
		allowedBiomes = new LinkedList<BiomeManager.BiomeEntry>();
		terraformedBiomes = new LinkedList<BiomeManager.BiomeEntry>();
		requiredArtifacts = new LinkedList<ItemStack>();
		isNativeDimension = true;
		hasRings = false;
		sealevel = 63;
		generatorType = 0;
	}

	public DimensionProperties(int id ,String name) {
		this(id);
		this.name = name;
	}

	public DimensionProperties(int id, boolean shouldRegister) {
		this(id);
	}

	@Override
	public Object clone() {
		try {
			return super.clone();
		} catch(CloneNotSupportedException e) {
			return null;
		}
	}

	/**
	 * @param world
	 * @return null to use default world gen properties, otherwise a list of ores to generate
	 */
	

	/**
	 * Resets all properties to default
	 */
	public void resetProperties() {
		fogColor = new float[] {1f,1f,1f};
		skyColor = new float[] {1f,1f,1f};
		sunriseSunsetColors = new float[] {.7f,.2f,.2f,1};
		
		requiredArtifacts = new LinkedList<ItemStack>();
		hasRings = false;
		sealevel = 63;
		oceanBlock = null;
		fillerBlock = null;
		generatorType = 0;
	}

	public int getId() {
		return TimeId;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void readFromNBT(NBTTagCompound nbt) {
		NBTTagList list;

		sealevel = nbt.getInteger("sealevel");
	}

	public void writeToNBT(NBTTagCompound nbt) {
		NBTTagList list;
		nbt.setInteger("sealevel", sealevel);
	}

	
	
	public int getSeaLevel() {
		return sealevel;
	}
	
	public void setSeaLevel(int sealevel) {
		this.sealevel = MathHelper.clamp(sealevel, 0, 255);
	}
	
	public void setId(int id) {
		this.TimeId = id;
	}

	public static DimensionProperties createFromNBT(int id, NBTTagCompound nbt) {
		DimensionProperties properties = new DimensionProperties(id);
		properties.readFromNBT(nbt);
		properties.TimeId = id;

		return properties;
		
	}
	
	
}
