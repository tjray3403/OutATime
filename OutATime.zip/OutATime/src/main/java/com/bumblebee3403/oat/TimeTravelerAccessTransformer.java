package com.bumblebee3403.oat;

import java.io.IOException;

import net.minecraftforge.fml.common.asm.transformers.AccessTransformer;

public class TimeTravelerAccessTransformer extends AccessTransformer
{
public TimeTravelerAccessTransformer() throws IOException
{
super("TimeTraveler_at.cfg");
}
}