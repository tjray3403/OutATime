package com.bumblebee3403.oat.util;

public interface IHasModel {

	public void registerModels();
}
