package com.bumblebee3403.oat.init;

import java.util.ArrayList;
import java.util.List;

import com.bumblebee3403.oat.items.ItemTimecart;

import net.minecraft.item.Item;

public class ItemInit {
	
	public static final List<Item> ITEMS = new ArrayList<Item>();

	public static final Item timecart = new ItemTimecart("timecart");
	
	
}
