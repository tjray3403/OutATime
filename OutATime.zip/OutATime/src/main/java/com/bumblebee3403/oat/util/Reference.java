package com.bumblebee3403.oat.util;

public class Reference {

	public static final String MOD_ID = "oat";
	public static final String NAME = "Out A Time";
	public static final String VERSION = "1.0";
	public static final String ACCEPTED_VERSIONS = "{1.12.2}";
	public static final String CLIENT_PROXY_CLASS = "com.bumblebee3403.oat.proxy.ClientProxy";
	public static final String COMMON_PROXY_CLASS = "com.bumblebee3403.oat.proxy.CommonProxy";
	
	public static final int GUI_TIME_TRAVEL = 9;
	public static final int ENTITY_PLAYER_PAST = 200;
	public static final int ENTITY_XP_ORB_TT = 199;
	public static final int ENTITY_PARADOX_HUNTER = 201;
	public static final int ENTITY_CHAIR = 202;
	public static final int ENTITY_TIMECART = 205;

	
	


	
}
